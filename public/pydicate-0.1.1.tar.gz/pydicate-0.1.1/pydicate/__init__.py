# pydicate: A library for generalized linguistic predicates
from pydicate.predicate import Predicate
