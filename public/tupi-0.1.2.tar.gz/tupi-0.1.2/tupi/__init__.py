# __init__.py

from .tupi import TupiAntigo
from .verb import Verb  # Replace with actual class or function names
from .noun import Noun  # Replace with actual class or function names
from .irregverb import IrregVerb  # Replace with actual class or function names
from .annotated_string import AnnotatedString  # Replace with actual class or function names
