import csv

with open('docs/citations.csv', 'r') as f:
    